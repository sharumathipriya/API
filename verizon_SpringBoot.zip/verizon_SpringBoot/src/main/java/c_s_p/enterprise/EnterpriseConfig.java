package c_s_p.enterprise;

public class EnterpriseConfig {

}
