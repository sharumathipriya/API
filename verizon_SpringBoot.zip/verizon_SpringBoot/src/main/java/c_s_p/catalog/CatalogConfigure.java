package c_s_p.catalog;

public class CatalogConfigure {

}
